<?php
    $headers = array(
        'Content-Type: application/json; charset=utf-8'
    );
    
    $consumerKey =  'QIi4GKdy4TOqbCTkWB6VMIJ6EpdHYGwg';
    $consumerSecret = 'Kq0iAKSKeLjXEtBe';

    
    $access_token_url='https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';


    // Request
    $curl = curl_init($access_token_url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
    //curl_setopt($ch, CURLOPT_HEADER, TRUE); // Includes the header in the output
    curl_setopt($curl, CURLOPT_HEADER, FALSE); // excludes the header in the output
    curl_setopt($curl, CURLOPT_USERPWD, $consumerKey . ":" . $consumerSecret); // HTTP Basic Authentication
    $result = curl_exec($curl);
    $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $result = json_decode($result);
    $access_token = $result->access_token;

    
    $balance_url = 'https://sandbox.safaricom.co.ke/mpesa/accountbalance/v1/query';

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $balance_url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Authorization:Bearer '.$access_token)); //setting custom header




    $curl_post_data = array(
    'Initiator' => 'TestInit613',
    'SecurityCredential' => 'SjnTFeAakocBiR2wZQBUpfsirFTfin0bAf/VcIWcGk+RtLbmeDDjY//eS+vk7iGeUdnSAqRZQlLpINN2WPtNPVPOvJz7qUvHRg4nF9Y864Ygk8eYMBnDV0/WqTTX6VMW+eelBNrcgkZdJaQcolrMYvDXToyFYEo/3kj1guIyiZ8gw/K7G0hzHFwFEPhxRrT5YWTNsHSXkE+P/ay28v8KuSv4faSI94qzyv9gsa6YmhaP5gFUBQF6N7CLRVXYDcIxq7KW7TcrzfE2wwJUgwkozd8ZHc8eV3dqHR1MdyY8bCv7kS8vgkyOGox2WHtkxFsGV9NTlfGNhBiQ7wB8cHpjaQ==',
    'CommandID' => 'AccountBalance',
    'PartyA' => '600613',
    'IdentifierType' => '4',
    'Remarks' => 'Bal',
    'QueueTimeOutURL' => 'https://amanivehiclesounds.co.ke/payments/balanceresponce.php',
    'ResultURL'       => 'https://amanivehiclesounds.co.ke/payments/balanceresponce.php'
    );

    $data_string = json_encode($curl_post_data);

    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);

    $curl_response = curl_exec($curl);
    print_r($curl_response);

    echo $curl_response;
    
?>
