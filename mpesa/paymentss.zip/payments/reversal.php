<?php
require "access_token.php";
$access_token = get_access_token();
$url = 'https://sandbox.safaricom.co.ke/mpesa/reversal/v1/request';

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Authorization:Bearer '.$access_token)); //setting custom header


$curl_post_data = array(
  //Fill in the request parameters with valid values
  'Initiator' => 'testapi120',
  'SecurityCredential' => 'mbALqbW8o+iBNkrkwWfrhMG30ugfo0FEL+CSDSD46BYsHuRTkT79vV3DBcoZ6PKZC557rVPP/Z5cusokRN4PE5OHHBHJ65TpMgTaBScz773b+48EfYaB9QpjS7FOYaiwxtA9zrAjOPRwVtFvzKYHhGopnvycJ10CUXvJ9WIfapel58ZUVmi0FzrPzXHe/ZgHW5itBX/X/pOQkV8t/5MDwR76saHm07W1y2AJByFp9jIWQmTT55YNmyrgZAS9GY6KXijl4DRxS0jW4u/FqH7RZY+v+6eyPxcWMq3aZxJs5u7PMoibCK9wFjZAhuaXLgWgKm90dGow8Moz8iWRw7b3Vg==',
  'CommandID' => 'TransactionReversal',
  'TransactionID' => 'LCV7254PVB',
  'Amount' => '1200',
  'ReceiverParty' => '600120',
  'RecieverIdentifierType' => '11',
  'ResultURL' => 'https://amanivehiclesounds.co.ke/payments/reverseresponce.php',
  'QueueTimeOutURL' => 'https://amanivehiclesounds.co.ke/payments/reverseresponce.php',
  'Remarks' => 'Out of Stock',
  'Occasion' => 'Web Purchase'
);

$data_string = json_encode($curl_post_data);

curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);

$curl_response = curl_exec($curl);
print_r($curl_response);

echo $curl_response;
?>
