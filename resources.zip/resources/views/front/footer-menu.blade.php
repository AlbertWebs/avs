<nav class="mobile-nav">
    <ul class="mobile-menu">
        <li class="active">
            <a href="{{url('/')}}">Home</a>
        </li>
        <li class="active">
            <a href="{{url('/')}}/products/shop-by-category">Shop By Category</a>
        </li>
        <li class="active">
            <a href="{{url('/')}}/products/shop-by-brand">Shop By Brand</a>
        </li>
        <li class="active">
            <a href="{{url('/')}}/products">All Products</a>
        </li>
        <li class="active">
            <a href="{{url('/')}}/blog-posts">Blog</a>
        </li>
        <li class="active">
            <a href="{{url('/')}}/find-us">Find Us</a>
        </li>
    </ul>
</nav><!-- End .mobile-nav -->