<div class="header-right">
    <i class="la la-lightbulb-o"></i><p> <a style="color:#ffffff;" href="{{url('/')}}/products-discounts/car-accessories">Discounts of Up to 15% Off</a>  </span> </p>
</div>